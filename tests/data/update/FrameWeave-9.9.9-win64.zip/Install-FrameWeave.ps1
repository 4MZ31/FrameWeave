# test-only stand-in for the real installer
